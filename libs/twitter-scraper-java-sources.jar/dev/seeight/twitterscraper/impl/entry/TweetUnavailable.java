package dev.seeight.twitterscraper.impl.entry;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import dev.seeight.twitterscraper.impl.Entry;
import dev.seeight.twitterscraper.impl.item.NotificationF;
import dev.seeight.twitterscraper.util.JsonHelper;

public class TweetUnavailable extends Entry {
    public NotificationF.RichMessage text;

    ///this is some shit i hacked together
    /// all it does is say the tweet is unavailable so sandstar archive wont crash
    /// there isnt actually any content returned when a tweet is unavailable. literally nothing.
    public static TweetUnavailable create(JsonHelper h) {
        TweetUnavailable t = new TweetUnavailable();
        JsonObject blah = new JsonObject();
        blah.addProperty("text","TweetUnavailable");
        blah.addProperty("rtl",false);
        JsonArray array = new JsonArray();
        blah.add("entities",array);
        t.text = NotificationF.RichMessage.fromJson(h, blah);
        return t;
    }
}
